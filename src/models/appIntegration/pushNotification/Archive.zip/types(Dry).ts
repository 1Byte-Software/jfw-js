import { DateType, IdType } from '../../base';
import { IAppIntegration } from '../types';

interface IAppIntegrationPushNotificationFields {
    /**
     * App integration ID for user
     */
    appIntegrationId: IdType;
    appIntegration: IAppIntegration;
    code: string;
    name?: string | null;
    projectId: IdType;
    clientEmail: string;
    clientId?: IdType | null;
    privateKey: string;
    authUrl?: string | null;
    tokenUrl?: string | null;
    authProviderX509CertUrl?: string | null;
    clientX509CertUrl?: string | null;
    universeDomain?: string | null;
    apiKey?: string | null;
    authDomain?: string | null;
    storageBucket?: string | null;
    messagingSenderId?: IdType | null;
    appId?: IdType | null;
    measurementId?: string | null;
    vapidKey?: string | null;
    createdDate: DateType;
}

export interface IAppIntegrationPushNotification
    extends Pick<
        IAppIntegrationPushNotificationFields,
        | 'appIntegration'
        | 'code'
        | 'name'
        | 'projectId'
        | 'clientEmail'
        | 'clientId'
        | 'privateKey'
        | 'authUrl'
        | 'tokenUrl'
        | 'authProviderX509CertUrl'
        | 'clientX509CertUrl'
        | 'universeDomain'
        | 'apiKey'
        | 'authDomain'
        | 'storageBucket'
        | 'messagingSenderId'
        | 'appId'
        | 'measurementId'
        | 'createdDate'
    > {}

//#region API types
export interface IGetAppIntegrationPushNotificationParams {}

export interface ICreateAppIntegrationPushNotificationData
    extends Pick<
        IAppIntegrationPushNotificationFields,
        | 'appIntegrationId'
        | 'code'
        | 'name'
        | 'projectId'
        | 'clientEmail'
        | 'clientId'
        | 'privateKey'
        | 'authUrl'
        | 'tokenUrl'
        | 'authProviderX509CertUrl'
        | 'clientX509CertUrl'
        | 'universeDomain'
        | 'apiKey'
        | 'authDomain'
        | 'storageBucket'
        | 'messagingSenderId'
        | 'appId'
        | 'measurementId'
        | 'vapidKey'
    > {}

export interface IGetBaseDRY
    extends Pick<IAppIntegrationPushNotificationFields, 'appIntegration'> {}

export interface IGetBaseWET {
    appIntegration: IAppIntegration;
}

const wet: IGetBaseWET = {};

export type IUpdateAppIntegrationPushNotificationData =
    ICreateAppIntegrationPushNotificationData;

//#endregion
